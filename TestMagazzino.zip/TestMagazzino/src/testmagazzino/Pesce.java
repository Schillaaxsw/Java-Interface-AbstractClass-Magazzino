/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagazzino;

/**
 *
 * @author schillaci.gabriel
 */
public abstract class Pesce {

    private int LuogoPesca;
    private int TempCons;

    public int getLuogoPesca() {
        return LuogoPesca;
    }

    public int getTempCons() {
        return TempCons;
    }

}
