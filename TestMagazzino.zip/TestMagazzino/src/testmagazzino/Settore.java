/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagazzino;

/**
 *
 * @author schillaci.gabriel
 */
public class Settore {

    private int posizione;
    private int mq;
    private int lotti;
    private int temperatura;
    private int getMqDisponibili;

    public int getPosizione() {
        return posizione;
    }

    public int getMq() {
        return mq;
    }

    public int getLotti() {
        return lotti;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public int getGetMqDisponibili() {
        return getMqDisponibili;
    }

}
