/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagazzino;

/**
 *
 * @author schillaci.gabriel
 */
public class Farina implements Prodotto, Pesabile {

    private int prezzoAlKg;
    private int peso;

    @Override
    public void setPeso(int peso) {

    }

    @Override
    public int getPeso() {
        return 0;

    }

    @Override
    public void getDescrizione() {

    }

    @Override
    public int getPrezzo() {
        return 0;

    }

}
